package PageObject;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage extends BasePage{
    private static final By CLICK_LOG = By.xpath("//span/a[@href]");
    private static final By HOMEPAGE_TEXT = By.xpath("//div[@class='starter-template']/p[1]");

    private String urlToFind = "http://13.40.154.83:8080/";
    public void goTo(){
        driver.get(urlToFind);
    }
    public void clickOnLoginLink(){waitAndClick(CLICK_LOG);}
    public void assertHomePageText(){
        String assertText = findText(HOMEPAGE_TEXT);
        Assert.assertEquals("This system is the be used by bank branch staff to complete applications for loans."
                , assertText);
    }
    public String returnUrl(){
        findUrlLink(urlToFind);
        String url = driver.getCurrentUrl();
        return url;
    }
}
