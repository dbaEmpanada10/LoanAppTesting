package StepDefinitions;

import PageObject.HomePage;
import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.WebDriver;

public class Hooks {
    public static WebDriver driver;
    static DriverFactory driverFactory;
    @Before
    public void Before(){
        driverFactory = new DriverFactory();
//        driver = driverFactory.getDriver();
        HomePage home = new HomePage();
        home.goTo();
    }
    @After
    public void After(){

    }
}
