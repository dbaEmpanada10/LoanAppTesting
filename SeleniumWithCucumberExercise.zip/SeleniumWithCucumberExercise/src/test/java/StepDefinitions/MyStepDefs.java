package StepDefinitions;

import PageObject.HomePage;
import PageObject.LoginPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import org.openqa.selenium.WebDriver;

public class MyStepDefs {
    private HomePage homePage;
    private LoginPage login;

    public MyStepDefs() {
        homePage = new HomePage();
        login = new LoginPage();
    }

    @Given("I am at the mainpage")
    public void iAmAtTHeMainpage(){
        homePage.assertHomePageText();
    }

    @When("I click on the login button")
    public void iClickOnTheLoginButton() {
        homePage.clickOnLoginLink();
    }

    @Then("I am redirected to the login page")
    public void iAmRedirectedToTheLoginPage() {
        login.assertLoginText();
    }
}
